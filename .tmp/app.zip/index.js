import { default as dataApiRequest_1_0 } from './functions/dataApiRequest/1.0';
import { default as dataApiRequest_1_1 } from './functions/dataApiRequest/1.1';
import { default as dataApiRequest_1_2 } from './functions/dataApiRequest/1.2';
import { default as dataApiRequest_1_3 } from './functions/dataApiRequest/1.3';
import { default as dataApiRequest_1_4 } from './functions/dataApiRequest/1.4';
import { default as dataApiRequest_1_5 } from './functions/dataApiRequest/1.5';
import { default as dataApiRequest_1_6 } from './functions/dataApiRequest/1.6';
import { default as dataApiRequest_1_7 } from './functions/dataApiRequest/1.7';

const fn = {
  "dataApiRequest 1.0": dataApiRequest_1_0,
  "dataApiRequest 1.1": dataApiRequest_1_1,
  "dataApiRequest 1.2": dataApiRequest_1_2,
  "dataApiRequest 1.3": dataApiRequest_1_3,
  "dataApiRequest 1.4": dataApiRequest_1_4,
  "dataApiRequest 1.5": dataApiRequest_1_5,
  "dataApiRequest 1.6": dataApiRequest_1_6,
  "dataApiRequest 1.7": dataApiRequest_1_7,
};

export default fn;
